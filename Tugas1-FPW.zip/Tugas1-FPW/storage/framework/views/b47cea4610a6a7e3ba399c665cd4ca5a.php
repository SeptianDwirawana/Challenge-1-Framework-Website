<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Biodata - <?php echo $__env->yieldContent('nama_title'); ?></title>
</head>
<body>
    <h1>BIODATA <?php echo $__env->yieldContent('nama_heading'); ?></h1>
</div>
<div id="bio">
    <p><?php echo $__env->yieldContent('bio'); ?></p>
</div>
<div id="bio">
    <div>
        Alamat:
    </div>
    <div>
        <?php echo $__env->yieldContent('alamat'); ?>
    </div>
</div>
<p><div id="bio">
    <div>
        Hobi:
    </div>
    <div>
        <?php echo $__env->yieldContent('hobi'); ?>
    </div>
</div></p>

</body>
</html><?php /**PATH C:\laragon\www\Tugas1-FPW\resources\views/utama.blade.php ENDPATH**/ ?>