

<?php $__env->startSection('nama_title',$nama); ?>

<?php $__env->startSection('nama_heading',$nama); ?>

<?php $__env->startSection('bio',$bio); ?>

<?php $__env->startSection('alamat',$alamat); ?>

<?php $__env->startSection('alamat'); ?>

<?php $__env->startSection('hobi'); ?>
<?php $__empty_1 = true; $__currentLoopData = $hobi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <li><?php echo e($item); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('utama', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Tugas1-FPW\resources\views/biodata.blade.php ENDPATH**/ ?>