<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Profil extends Controller
{
    public function index(){
        
        $nama = "Septian Dwirawana";
        $bio = "Saya lahir di Bekasi pada 14 September 2002, saya sekolah dasar di SDN Sumberjaya 03, lalu melanjutkan sekolah menengah pertama di MTs PINK 03,
        dan lanjut di SMA Yadika 13 lulus tahun 2020, lalu mencoba masuk ke sekolah kedinasan tetapi gagal dan nganggur selama satu tahun, 
        lalu memutuskan untuk kuliah pada tahun 2021 di Universitas Singaperbangsa Karawang";
        $alamat = "Griya asri 2 Blok H14 no.9 Rt.08 Rw.024 Jl.Cendrawasih 7, Tambun Selatan, Bekasi";
        $hobi = ["Badminton","Bermain game","Bersepedah"];
        return view('biodata',['nama'=>$nama, 'bio'=>$bio, 'alamat'=>$alamat, 'hobi'=>$hobi]);
    }
}